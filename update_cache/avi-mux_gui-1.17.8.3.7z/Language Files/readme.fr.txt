The french translation has been made by "Luigi Brosse" some time
ago, and I have fixed a few typos and updated it when necessary

If you spot any typos in the french languages file, just contact me.