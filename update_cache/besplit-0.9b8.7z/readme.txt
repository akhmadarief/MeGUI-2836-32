BeSplit v0.9b8 by DSPguru.
----------------------------
this program started as a simple WAV/AC3/AAC/MPA/MP3/MP2/MP1/PCM/DTS/DTS-WAV Cutter.
now it's more of a mutlimedia streams manipulator.

Warrenty
---------
I take no responsibility for any kind of damage caused by BeSplit. 
Use this program at your own risk!


Information
-----------
Usage :
BeSplit -core( .. ) -split( .. )

core   switches sets files arguments & engine behavior.
split  section holds the list of timestamps to be splitted.
ota    switches sets the Overall Track paremeters.

for full switches list of 'core', please run BeSplit.exe on a dos-window.
for ota's switches, read attached 'ota.txt'.
for usage examples, read attached Examples.txt.

Latest releases can be found at:
	http://BeSplit.doom9.net
for updated info about this program, visit Doom9's "Audio Encoding" forum :
	http://forum.doom9.net/forumdisplay.php?s=&forumid=11
for bug-reports and features-requests, post your comments here :
	http://forum.doom9.org/showthread.php?s=&threadid=24690


DSPguru would like to thank :
Mr. Midas  - for the inspiration.
DVD2SVCD   - for asking me to add MPA&WAV support.
Roberto A. - for asking me to add AAC support.
RUOK       - for writing WBIAS (a GUI for BeSplit) and supplying important feedbacks.
mpucoder   - for asm86 help.