BASS_AAC 2.4

� 2002-2012, Sebastian Andersson (sebastian.andersson@gmail.com). All rights reserved.
Portions � 2006, M. Bakker, Nero AG. All rights reserved.

All trademarks and other registered names contained in the BASS_AAC
package are the property of their respective owners.


What is BASS_AAC?
=================
BASS_AAC is an extension to the BASS audio library that enables the playback
of Advanced Audio Coding and MPEG-4 streams.


What are AAC and MP4?
=====================
Please visit:

http://www.vialicensing.com/products/mpeg4aac/standard.html


Disclaimer
==========
BASS_AAC is provided "as is" and without warranties of any kind, either express
or implied. The author assumes no liability for damages, direct or consequential,
which may result from the use of BASS_AAC.


Costs
=====
The BASS_AAC library is free to use and distribute as long as you follow the guidelines
of the GPL.

If you enjoy BASS_AAC, please consider donating money. You may use PayPal to make a donation:

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=sebastian%2eandersson%40gmail%2ecom&item_name=BASS%20Add%2dOns&item_number=1&no_shipping=1&no_note=1&tax=0&currency_code=EUR

For commercial use of BASS_AAC, please contact Nero AG at:
Mpeg4AAClicense@nero.com

For information regarding patent licensing for AAC, please see Via Licensing's website:
http://www.vialicensing.com/products/mpeg4audio/standard.html

For information regarding patent licensing for aacPlus, please see Coding Technologies'
website:
http://www.codingtechnologies.com/licensing/aacplus.htm